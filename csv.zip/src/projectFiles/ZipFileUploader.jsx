import React, { useState } from 'react';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import { GrDocumentZip } from 'react-icons/gr';

const ZipFileUploader = () => {
  const [files, setFiles] = useState([]);
  const [max, setMax] = useState(100);
  const [progressValue, setProgressValue] = useState(0);

  const handleFolderChange = async (event) => {
    const selectedFiles = event.target.files;
    const fileArray = Array.from(selectedFiles);

    const childFolderNames = Array.from(new Set(fileArray.map(file => file.webkitRelativePath.split('/')[1])));
    console.log('Child Folders:', childFolderNames);
    
    setMax(childFolderNames.length);
    await processFiles(fileArray, childFolderNames);
    setFiles(fileArray);
  };

  async function processFiles(fileArray, folderNames) {
    for (let index = 0; index < folderNames.length; index++) {
      const childFolder = folderNames[index];
      const reqData = fileArray.filter(file => file.webkitRelativePath.split('/')[1] === childFolder);

      console.log('Processing Folder:', childFolder);
      setProgressValue(index + 1);

      await createZipFile(reqData, childFolder, folderNames);
    }
  }

  let childsMaster = {};
  
  const createZipFile = (files, childFolderName, folderNames) => {
    console.log('Creating Zip for:', childFolderName);

    return new Promise((resolve) => {
      const zip = new JSZip();

      files.forEach(file => {
        const newPath = file.webkitRelativePath.split('/').slice(2).join('/');
        zip.file(newPath, file);
      });

      zip.generateAsync({ type: 'blob' }).then(content => {
        childsMaster[childFolderName] = content;

        if (folderNames[folderNames.length - 1] === childFolderName) {
          const parentZip = new JSZip();

          Object.keys(childsMaster).forEach(folderName => {
            parentZip.file(`${folderName}.zip`, childsMaster[folderName]);
          });

          parentZip.generateAsync({ type: 'blob' }).then(parentContent => {
            const parentFolderName = files[0].webkitRelativePath.split('/')[0];
            console.log('Parent Folder Name:', parentFolderName);
            saveAs(parentContent, `${parentFolderName}.zip`);
            setProgressValue(0);
          });
        }

        resolve();
      });
    });
  };

  return (
    <div>
      <br />
      <h4><span style={{ color: "#f36633" }}>Create zipper</span> file</h4><br />
      <span id='download-btn'>
        <input
          type="file"
          webkitdirectory="true"
          mozdirectory="true"
          msdirectory="true"
          odirectory="true"
          directory="true"
          multiple
          style={{ color: "white" }}
          onChange={handleFolderChange}
        />
        <GrDocumentZip /><br />
      </span>
      <br />
      <progress id="file" style={{ color: "red" }} value={progressValue} max={max}></progress>
    </div>
  );
};

export default ZipFileUploader;
