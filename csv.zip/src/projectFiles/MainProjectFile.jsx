import  { useState } from 'react';
import * as XLSX from 'xlsx';
import exportFromJSON from 'export-from-json';
import "./MainProjectFile.css"
import { FaDownload } from "react-icons/fa";
import Hogartlogo from "./images/hogarthlogo.png"
import { BsFiletypeJson } from "react-icons/bs";
import { SiMicrosoftexcel, SiTekton } from "react-icons/si";
import { GrDocumentZip } from "react-icons/gr";
import { GrSettingsOption } from "react-icons/gr";
import ZipFileUploader from './ZipFileUploader';



function MainProjectFile() {
  // const [fileContent, setFileContent] = useState('');
  const [file, setFile] = useState(null);
  const [slideData, setSlideData] = useState([]);
  const [slideTitle, setSlideTitle] = useState([]);//this is for the slide name
  const [isDescription, setDescription] = useState([])
  const [isUserGroups, setUserGroups ] = useState()
  const [isBinderData, setIsBinderData] = useState([]);
  const [slidetherapy, setSlideTherapy] = useState([]);
  const [slidedisease, setSlidedisease] = useState([]);
  const [slidecountry, setSlidecountry] = useState([]);
  const [slideproduct, setSlideproduct] = useState([]);
  const [slideglobalproduct, setSlideGlobalproduct] = useState([]);
  const [slideexpiration, setSlideexpiration] = useState([]);
  const [slidelanguage, setSlidelanguage] = useState([]);
  const [slidecrmorg, setSlidecrmorg] = useState([]);
  const [crmProduct, setCrmProduct] = useState("");
  const [DocumentNumber , setDocumentNumber] = useState("");
  

  
  
  


  const handleFileChange = (event) => {
    
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onload = (e) => {
      const content = e.target.result;
      // setFileContent(content);
      console.log(content)
      HandleResult(content)
    };

    reader.readAsText(file);
    
  };

  const HandleResult = (fileContent)=>{
    // console.log(fileContent)

    // for finding pagesall
    const regex = /"pagesAll": \[([^\]]+)\]/;
    const matches = fileContent.match(regex);
    if (matches && matches.length > 1) {
      const trimmedContent = matches[1].trim();
      let stringWithoutBreaks = trimmedContent.replace(/(\r\n|\n|\r)/gm, "");
      // //console.log(trimmedContent);
      let arr = stringWithoutBreaks.split(",")
      const regex = /(?<=")[^"]+(?=")/g;
console.log(arr)
const result = arr.map(str => str.match(regex)[0]);
result.push(`${isBinderData[0]["external_id__v"]}_shared`) //to add last value of external id;
const slideData= result.map((slideId,index) => genrateData({type: "slide", slideId},index) );

//console.log(slideData)
setSlideData(slideData)
      // arr.forEach((pages, index)=>{
      //   ////console.log(pages,"folders.zip for")
      //   newarr.push(pages.replace)
      // })
      
    } else {
      //console.log("No match found.");
    }

    // for finding pagenames
    const regex2 = /"pagesTitles": \[([^\]]+)\]/;
    const matches2 = fileContent.match(regex2);
    if (matches2 && matches2.length > 1) {
      const trimmedContent = matches2[1].trim();
      let stringWithoutBreaks = trimmedContent.replace(/(\r\n|\n|\r)/gm, "");
      // //console.log(trimmedContent);
      let arr = stringWithoutBreaks.split(",")
      const regex = /(?<=")[^"]+(?=")/g;

const result = arr.map(str => str.match(regex)[0]);
// //console.log(result)
const slideTitle= result.map((slideName,index) => genrateData({type: "slidetitle", slideName},index) );

setSlideTitle(slideTitle)


    } else {
      //console.log("No match found.");
    }


    // for finding Description
    const regex3 = /"pagesDesc": \[([^\]]+)\]/;
    const matches3 = fileContent.match(regex3);
    if (matches3 && matches3.length > 1) {
      const trimmedContent = matches3[1].trim();
      let stringWithoutBreaks = trimmedContent.replace(/(\r\n|\n|\r)/gm, "");
      // //console.log(trimmedContent);
      let arr = stringWithoutBreaks.split(",")
      const regex = /(?<=")[^"]+(?=")/g;
      const result = arr.map(str => str.match(regex)[0]);
      //console.log(result,"description") 
      const Description= result.map((description,index) => genrateData({type: "description", description},index) );
      setDescription(Description)
      //console.log(result);


    } else {
      //console.log("No match found.");
    }

  }
  
  //
  const handleExcelRead  = (e)=>{

    const selectedFile = e.target.files[0];
    setFile(selectedFile);
    handleFile(selectedFile);
    

  }

  // CRM Org deffines the vaules

 
  // to read excel file
  const handleFile = (file) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const workbook = XLSX.read(e.target.result, { type: 'binary' });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const data = XLSX.utils.sheet_to_json(sheet);
      //console.log(data,".................................")
      //console.log(data[0]["CRM Org"])
      
        
     
      
      //console.log(data[0]["Document Name"],"Hi................")
      localStorage.setItem("presentation_name",data[0]["Binder Name"])
      //console.log(data[0]["User Groups"])
      
      setUserGroups(data[0]["User Groups"])

      const newData =  genrateData(data[0])
      setIsBinderData([newData]);

      const slidetherapy = genrateData(data[0]);
      setSlideTherapy([slidetherapy]);

      const slidedisease = genrateData(data[0]);
      setSlidedisease([slidedisease]);
      
      const slidecountry = genrateData(data[0]);
      setSlidecountry([slidecountry]);

      const slideproduct = genrateData(data[0]);
      setSlideproduct([slideproduct]);

      const slideGlobalproduct = genrateData(data[0]);
      setSlideGlobalproduct([slideGlobalproduct]);

      const slideexpiration = genrateData(data[0]);
      setSlideexpiration([slideexpiration]);

      const slidelanguage = genrateData(data[0]);
      setSlidelanguage([slidelanguage]);
      
      const slidecrmorg = genrateData(data[0]);
      setSlidecrmorg([slidecrmorg])

    };

   

    reader.readAsBinaryString(file);
  };

  
 
  // genrate CSV file
const handelDownloade = ()=>{
const fileName = 'download'
const exportType =  exportFromJSON.types.csv
//console.log(slideTitle)
let tempArr = [...isBinderData, ...slideData]
//console.log(tempArr)
let newone = slideData[0]
let originalString = localStorage.getItem("presentation_name").trim()
newone["name__v"] = originalString.split("(")[0].trim();


slideTitle.unshift(newone)
// slideTitle[0]["name__v"] = localStorage.getItem("presentation_name");
// //console.log(slideTitle);
slideTitle.map((item,index,arr)=>{
  // if(index === 0){
  //   tempArr[index]["name__v"] = ""
  // }else{
  //   tempArr[index]["name__v"] = arr[index-1]["name__v"]
  // }
  // //console.log(item["name__v"])
  tempArr[index]["name__v"] = item["name__v"]
})
isDescription.unshift("")

isDescription.map((item,index,arr)=>{
  tempArr[index]["slide.title__v"] = item["slide.title__v"]
})
//console.log(isUserGroups,"isUserGroups...................................")

isDescription.map((item,index,arr)=>{
  index ==0 ?tempArr[index]["slide.user_groups__c"] =  "":tempArr[index]["slide.user_groups__c"] = isUserGroups
  
})

isDescription.map((item,index,arr)=>{
  index == 0 ? tempArr[index]["slide.clm_content__v"] = "" : tempArr[index]["slide.clm_content__v"] = "YES"
  index == 0 ? tempArr[index]["slide.crm_disable_actions__v"] = "" : tempArr[index]["slide.crm_disable_actions__v"] = "Swipe"
  index == 0 ? tempArr[index]["slide.crm_shared_resource__v"] = "" : tempArr[index]["slide.crm_shared_resource__v"] = "NO"
  index == 0 ? tempArr[index]["slide.engage_content__v"] = "" : tempArr[index]["slide.engage_content__v"] = "NO"
  index == 0 ? tempArr[index]["slide.crm_media_type__v"] = "" : tempArr[index]["slide.crm_media_type__v"] = "HTML"
  
})






// isDescription.map((item,index,arr)=>{
//   if(index == arr.length-1 ){
//     tempArr[index]["Presentation Link"] = ""
//   }

// })

//to place last line in excel sheet 

//console.log(tempArr,"newon")




exportFromJSON({ data:tempArr, fileName, exportType })
}



const DateConverter = (base32Number) =>{

  // Convert Unix timestamp to date string
  const dateString = convertExcelDateToDateString(base32Number);
  //console.log(dateString)
  return dateString

}

// Function to convert Excel serial date number to date string in "mm/dd/yyyy" format
function convertExcelDateToDateString(excelDate) {

  //console.log(excelDate)
  // Define the base date (January 1, 1900)
  const baseDate = new Date(1900, 0, -1); // Months are zero-based, so 0 = January

  // Calculate the actual date by adding the Excel serial date number
  const actualDate = new Date(baseDate.getTime() + excelDate * 86400000); // 86400000 ms in a day
  //console.log(actualDate,"actualdate")
  // Format the date as "mm/dd/yyyy"
  const month = String(actualDate.getMonth() + 1).padStart(2, '0');
  const day = String(actualDate.getDate()).padStart(2, '0');
  const year = actualDate.getFullYear();

  // Return the formatted date string
  return `${month}/${day}/${year}`;
}

// // Example usage:
// const excelDate = 45303; // Example Excel serial date number
// const dateString = convertExcelDateToDateString(excelDate);
// //console.log(dateString); // Outputs: "12/01/2024"


  // const handleStandardExcel = async()=>{
  //   try {
  //     const response = await fetch('./orginal.xlsx');
  //     const arrayBuffer = await response.arrayBuffer();
  //     // //console.log(arrayBuffer)
  //     const workbook = XLSX.read(arrayBuffer, { type: 'array' });
  //     const sheetName = workbook.SheetNames[0];
  //     //console.log(sheetName)
  //     const sheet = workbook.Sheets[sheetName];
  //     const data = XLSX.utils.sheet_to_json(sheet);
  //     //console.log(data)
      
  //   } catch (error) {
  //     console.error('Error fetching data:', error);
  //   }
  // }

  

  return (
    <div className='MainContainer'>
<div className="area" >
            <ul className="circles">
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
            </ul>
    </div >
      <div className='innerContainer'>
      <div style={{textAlign:"center",width:"100%"}}><img src={Hogartlogo} className="hogarth_Login"  /></div>
      <div id='csvGen'>
        <span style={{color:'#f36633'}}>CSV Gen</span> Tool<br/>
      </div>
      <label>Document ID : <input placeholder='Enter Document Number' type="text" value={DocumentNumber} onChange={(e)=>setDocumentNumber(e.target.value)} /></label>
        {/* to create process */}<br/><br/>


       {/* get the CRM Product  */}
       <label>CRM Product : <input type="text" placeholder='Enter Crm Product'  value={crmProduct} onChange={(e)=>setCrmProduct(e.target.value)} /></label><br /><br />

         {/* to read vault excel file  */}
         <div className='box'><label>Excel file :&nbsp; &nbsp;</label>
         {console.log(DocumentNumber,DocumentNumber.length>0)}
      <input className='inputfile' disabled = {crmProduct.length>0 && DocumentNumber.length>0?false:true } type="file" onChange={handleExcelRead} />
      <label id={crmProduct.length>0 && DocumentNumber.length>0 ?"noDisable":"disable" } className='lableinput'><SiMicrosoftexcel /> <span>Choose a file…</span></label>
</div><br />

         {/* to read config file upload and read required values */}
         <div className='box'><label>Config file : </label>
      <input type="file" className='inputfile' disabled = {crmProduct.length>0 && DocumentNumber.length>0 && file ?false:true } onChange={handleFileChange} />
      <label id={crmProduct.length>0 && DocumentNumber.length>0 && file?"noDisable":"disable" } className='lableinput'><BsFiletypeJson/> <span>Choose a file…</span></label>
      </div><br />

    <div className='download-container'>
      <button id='download-btn' disabled = {crmProduct.length>0 && DocumentNumber.length>0 && file ?false:true }  onClick={handelDownloade}>Download CSV <FaDownload /></button>
      {/*<button id='download-btn' disabled = {crmProduct.length>0 && DocumentNumber.length>0 && file ?false:true }  onClick={handelDownloade}>Zip Folders <GrDocumentZip /></button>*/}
      {/* <button id='download-btn' disabled = {crmProduct.length>0 && DocumentNumber.length>0 && file ?false:true }  onClick={handelDownloade}>Package Presentation <GrSettingsOption /></button> */}
    <ZipFileUploader/>
    </div>

    
      <div>
      </div>
      </div>
     

    </div>
  );
}

export default MainProjectFile;