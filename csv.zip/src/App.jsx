import './App.css'
import MainProjectFile from './projectFiles/MainProjectFile'

function App() {

  return (
    <>
     <MainProjectFile/>
    </>
  )
}

export default App
